import requests
from bs4 import BeautifulSoup
from datetime import datetime
import hashlib
import random
import string
import time
#时间戳转化
def convert_to_timestamp(time_string):
    try:
        timestamp = int(time.mktime(time.strptime(time_string, "%Y-%m-%d %H:%M:%S")))
        return timestamp
    except ValueError:
        print("Invalid time format")
        return None

#随机生成编号
def generate_random_md5():
    # 生成随机字符串作为输入数据
    random_string = ''.join(random.choices(string.ascii_letters + string.digits, k=10))

    # 计算MD5哈希值
    md5_hash = hashlib.md5(random_string.encode()).hexdigest()

    return md5_hash

def get_formatted_date():
    # 获取当前日期
    current_date = datetime.now().date()

    # 将日期转换为指定格式的字符串
    formatted_date = current_date.strftime("%Y%m%d")

    return formatted_date



def get_formatted_date2():
    # 获取当前日期
    current_date = datetime.now().date()

    # 将日期转换为指定格式的字符串
    formatted_date = current_date.strftime("%Y-%m-%d")

    return formatted_date



def get_sw_url():
    date1 = get_formatted_date()
    date2 = get_formatted_date2()
    results = []  # 存储所有条目的列表
    for i in range(0,4):
        for m in range(0,10):
            for k in range(0,10):


                response = requests.get("http://news.e23.cn/jnnews/{}/{}00{}{}{}.html".format(date2,date1,i,m,k))

                if response.status_code == 200:

                    soup = BeautifulSoup(response.content, 'html.parser')

                    # 找到包含标题内容的标签
                    main_content = soup.find('div', class_='content')

                    if main_content is not None:
                        # 提取标题
                        title_tag = main_content.find('h1')
                        if title_tag is not None:
                            title = title_tag.get_text().strip()
                            url = "http://news.e23.cn/jnnews/{}/{}00{}{}{}.html".format(date2,date1,i,m,k)
                            result = {
                                "title": title,
                                "url": url

                            }
                            #print("标题:", title,"http://news.e23.cn/jnnews/{}/{}00{}{}{}.html".format(date2,date1,i,m,k),)
                            results.append(result)

                        else:
                            print("未找到标题标签"+str(i)+str(m)+str(k))
                    else:
                        print("未找到内容标签"+str(i)+str(m)+str(k))


                else:
                    print("请求失败，状态码：" + str(response.status_code))
    return results

def jx_sw(url):
    news = {'标题': 'value1', '媒体': '舜网', '时间': 'value3','正文': 'value3','地址': 'value3'}  # 创建带有初始键值对的字典
    # 发送HTTP GET请求获取网页内容
    response = requests.get(url)

    # 检查响应状态码，200表示请求成功
    if response.status_code == 200:
        # 使用BeautifulSoup解析HTML内容
        soup = BeautifulSoup(response.content, 'html.parser')

        # 找到包含标题内容的标签
        main_content = soup.find('div', class_='content')

        # 提取标题
        title = main_content.find('h1').get_text().strip()
        # 提取来源
        source = soup.find('div', class_='content_p1_time').find('a').text
        # 提取时间
        time = soup.find('div', class_='content_p1_time').text.split('　')[0].strip()

        # 提取作者
        author = soup.find('div', class_='content_p1_author').text.strip()


         # 找到包含正文内容的标签
        main_content = soup.find('div', class_='content_text')
            # 提取正文内容
        text_content = main_content.get_text()#正文内容
            # 打印提取的正文内容

        news['正文'] = text_content
        news['标题'] = title
        news['记者'] = author
        news['时间'] = time
        news['来源'] = source
        news['地址'] = url
        return news


def sw_engin():
    data = []
    entries=get_sw_url()
    for entry in entries:
        link = (entry["url"])
        title = (entry["title"])

        time_content = jx_sw(link)
        time = time_content['时间'].rstrip()


        timestamp = convert_to_timestamp(time)
        source="舜网"
        author=time_content['记者'].rstrip()
        content=time_content['正文'].rstrip()
        number = "舜网" + generate_random_md5()
        new_item = [title, time, timestamp, source, author, content, link, number]
        data.append(new_item)
    return data


