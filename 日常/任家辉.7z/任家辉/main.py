from shujvku import post_sql_news,delete_sql,from_sql_check_delete,merge_tables
from dzw import dzw_engine
from sdxw import sdxw_engine
from hpxw import hpxw_engine
from sw import sw_engin
import time

def dzw_work():
    delete_sql("dzw_temporary")
    post_sql_news("dzw_temporary",dzw_engine("2"))
    from_sql_check_delete("dzw_temporary","dzw")
    merge_tables("dzw_temporary","dzw")
    delete_sql("dzw_temporary")


def sdxw_work():
    delete_sql("sdxw_temporary")
    post_sql_news("sdxw_temporary",sdxw_engine("济南",2))
    from_sql_check_delete("sdxw_temporary","sdxw")
    merge_tables("sdxw_temporary","sdxw")
    delete_sql("sdxw_temporary")

def hbxw_work():
    delete_sql("hbxw_temporary")
    post_sql_news("hbxw_temporary", hpxw_engine(2))
    from_sql_check_delete("hbxw_temporary", "hbxw")
    merge_tables("hbxw_temporary", "hbxw")
    delete_sql("hbxw_temporary")

def sw_work():
    delete_sql("sw_temporary")
    post_sql_news("sw_temporary", sw_engin())
    from_sql_check_delete("sw_temporary", "sw")
    merge_tables("sw_temporary", "sw")
    delete_sql("sw_temporary")

while True:
    try:
        # 执行你的任务代码
        dzw_work()
        sdxw_work()
        hbxw_work()
        sw_work()


    except Exception as e:
        # 发生异常时的处理逻辑
        print("执行任务出现异常:", str(e))

    # 等待1分钟
    time.sleep(1800)