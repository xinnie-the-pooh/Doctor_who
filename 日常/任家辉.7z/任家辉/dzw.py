import requests
from bs4 import BeautifulSoup
import re
import time
from fake_useragent import UserAgent
import hashlib
import random
import string


#随机生成编号
def generate_random_md5():
    # 生成随机字符串作为输入数据
    random_string = ''.join(random.choices(string.ascii_letters + string.digits, k=10))

    # 计算MD5哈希值
    md5_hash = hashlib.md5(random_string.encode()).hexdigest()

    return md5_hash

#时间戳转化
def convert_to_timestamp(time_string):
    try:
        timestamp = int(time.mktime(time.strptime(time_string, "%Y-%m-%d %H:%M:%S")))
        return timestamp
    except ValueError:
        print("Invalid time format")
        return None


#正则表达函数用于提取时间作者来源
def zzbd(label):
    # 定义正则表达式模式
    time_pattern = r"\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}"
    source_pattern = r"来源: (.+?)　作者:"
    author_pattern = r"作者: (.+)"

    # 使用正则表达式匹配时间、来源和作者
    time_match = re.search(time_pattern, label)
    source_match = re.search(source_pattern, label)
    author_match = re.search(author_pattern, label)

    # 提取匹配的结果
    time = time_match.group() if time_match else None
    source = source_match.group(1) if source_match else None
    author = author_match.group(1) if author_match else None

    return (time,source,author)

#该函数用于获得大众网的新闻列表传入参数页码返回result包含标题和链接
def get_dzw_url(pages):


    if pages == 1:
        url="http://jinan.dzwww.com/qcxw/default.htm"
    else:
        url="http://jinan.dzwww.com/qcxw/default_{}.htm".format(pages)

    try:


        ua = UserAgent()
        user_agent = ua.random
        # 构造请求头
        headers = {
            'User-Agent': user_agent,
            'Referer': 'Your Referer',
            # 其他请求头...
        }
        # 发送GET请求获取网页内容
        response = requests.get(url,headers=headers)
        # 设置编码格式
        response.encoding = "gbk"
        html_content = response.text
        # 使用BeautifulSoup解析网页内容
        soup = BeautifulSoup(response.text, 'html.parser')

        # 查找所有class为"style"的li元素
        li_elements = soup.find_all("li", class_="style")

        results = []  # 存储所有条目的列表
        # 遍历每个li元素，提取标题信息
        for li in li_elements:
            title_element = li.find("h3").find("a")
            title = title_element.text
            link = title_element["href"]

            result={
                "title": title,
                "url": link

            }
            results.append(result)

        return results

    except requests.RequestException as e:
        return {"error": f"发生错误：{e}"}

def jx_dzw(url):
    try:
        # 发送GET请求获取网页内容
        response = requests.get(url)
        # 设置编码格式
        response.encoding = "utf-8"
        # 使用BeautifulSoup解析网页内容
        soup = BeautifulSoup(response.text, 'html.parser')


        # 找到正文
        content = soup.find('div', class_='news-con').get_text()

        # 使用正则表达找到时间作者来源
        label = soup.find('div', class_='layout').get_text()


        time,source,author= zzbd(label)

        #时间，来源，记者，正文
        return time,source,author,content


    except requests.RequestException as e:
        return {"error": f"发生错误：{e}"}

def dzw_engine(pages):
    data=[]
    for i in range(1, int(pages)):
        title_urls=get_dzw_url(i)

        for title_url in title_urls:
            time,source,author,content = jx_dzw(title_url['url'])
            url=title_url['url']
            title=title_url['title']
            timestamp=convert_to_timestamp(time)
            number="大众网"+generate_random_md5()
            new_item=[title,time,timestamp,source,author,content,url,number]
            data.append(new_item)
    print(data)
    return data



#url="http://jinan.dzwww.com/qcxw/202308/t20230814_12547347.htm"
#print(jx_dzw(url))
dzw_engine("2")
