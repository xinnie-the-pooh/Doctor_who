import pymysql

# 替换下面的信息为你的数据库连接信息
host = "124.221.183.234"  # 数据库主机名或IP地址
user = "news"  # 数据库用户名
password = "WKhAsknmwH8ePMpZ"  # 数据库密码
database = "news"  # 数据库名称


#该函数用于把数据发送至数据库特定的表参数data为列表
def post_sql_news(biao,data):
    # 建立与MySQL数据库的连接
    connection = pymysql.connect(
        host=host,
        user=user,
        password=password,
        database=database
    )

    # 创建一个游标对象
    cursor = connection.cursor()

    # 使用循环插入每一行数据
    for row in data:
        # 构建插入语句
        sql = "INSERT INTO {} (标题, 时间, 时间戳, 来源, 作者, 正文, url, 编号) VALUES (%s, %s, %s, %s, %s, %s, %s, %s)".format(biao)

        # 执行插入语句
        cursor.execute(sql, row)

    # 提交更改并关闭连接
    connection.commit()
    connection.close()

#该函数用于删除指定的表内容
def delete_sql(biao):
    # 建立数据库连接
    cnx = pymysql.connect(
        host=host,
        user=user,
        password=password,
        database=database
    )

    # 创建游标对象
    cursor = cnx.cursor()

    # 执行删除数据的SQL语句
    delete_query = "DELETE FROM {}".format(biao)
    cursor.execute(delete_query)

    # 提交更改
    cnx.commit()
    print("已成功删除{}".format(biao))
    # 关闭游标和数据库连接
    cursor.close()
    cnx.close()


#该函数用于将biao1表的数据插入到biao2表中
def merge_tables(biao1,biao2):
    # 连接数据库
    connection = pymysql.connect(
        host=host,
        user=user,
        password=password,
        database=database
    )

    try:
        with connection.cursor() as cursor:
            # 查询biao1表中的所有数据
            cursor.execute("SELECT * FROM {}".format(biao1))
            zhaobiao_data = cursor.fetchall()

            # 将biao1表的数据插入到biao2表中
            for row in zhaobiao_data:
                cursor.execute("INSERT INTO {} (标题, 时间, 时间戳, 来源, 作者, 正文, url, 编号) VALUES (%s, %s, %s, %s, %s, %s, %s, %s)".format(biao2), row)

        # 提交更改
        connection.commit()

    finally:
        # 关闭数据库连接
        connection.close()



#这个函数会查询"biao1"表和"biao2"表的所有数据并进行比较。删除在"biao1"表中与"biao2"表重复的数据。
def from_sql_check_delete(biao1,biao2):
    # 连接数据库
    connection = pymysql.connect(
        host=host,
        user=user,
        password=password,
        database=database
    )

    try:
        with connection.cursor() as cursor:
            cursor.execute("DELETE FROM {} USING {},{} WHERE {}.标题={}.标题".format(biao1,biao1,biao2,biao1,biao2))

        # 提交更改
        connection.commit()

    finally:
        # 关闭数据库连接
        connection.close()
    print("已经检查去重完毕")




