import requests
from datetime import datetime
from bs4 import BeautifulSoup
import time
from fake_useragent import UserAgent

import hashlib
import random
import string


#随机生成编号
def generate_random_md5():
    # 生成随机字符串作为输入数据
    random_string = ''.join(random.choices(string.ascii_letters + string.digits, k=10))

    # 计算MD5哈希值
    md5_hash = hashlib.md5(random_string.encode()).hexdigest()

    return md5_hash


#时间戳转化
def convert_to_timestamp(time_string):
    try:
        timestamp = int(time.mktime(time.strptime(time_string, "%Y-%m-%d %H:%M:%S")))
        return timestamp
    except ValueError:
        print("Invalid time format")
        return None


#该函数用于获取指定关键词的闪电新闻链接的指定页数url
def get_sdxw_url(keyword, pages):
    url = "https://sdxw-datagrand.iqilu.com/search/article?keyword={}&page={}".format(keyword, pages)

    # 创建UserAgent对象
    ua = UserAgent()

    # 生成随机的User-Agent
    random_user_agent = ua.random

    # 设置请求头中的User-Agent
    headers = {'User-Agent': random_user_agent}

    response = requests.get(url, headers=headers)

    if response.status_code == 200:
        json_data = response.json()

        results = []  # 存储所有条目的列表

        for entry in json_data['data']:
            result = {
                "ID": entry['id'],
                "Title": entry['title'],
                "Thumbnail": entry['thumbnail'],
                "URL": entry['_url'],
                "Publish Time": entry['publish_at'],
                "PV": entry['pv'],
                "Copy From": entry['copyfrom']
            }
            results.append(result)

        return results  # 返回所有条目的列表
    else:
        print("Failed to retrieve JSON data. Status code:", response.status_code)


#该函数用于解析闪电新闻网页的时间和内容
def jx_sdxw(url):
    try:
        # 创建UserAgent对象
        ua = UserAgent()

        # 生成随机的User-Agent
        random_user_agent = ua.random

        # 设置请求头中的User-Agent
        headers = {'User-Agent': random_user_agent}




        # 发送GET请求获取网页内容
        response = requests.get(url,headers=headers)

        # 使用BeautifulSoup解析网页内容
        soup = BeautifulSoup(response.text, 'html.parser')

        # 找到具有details_author类的div元素
        details_author_div = soup.find('div', class_='details_author')

        # 找到具有art_content类的div元素
        art_content_div = soup.find('div', class_='art_content')


        result = {}

        if details_author_div:
            result['time'] = details_author_div.get_text()
        else:
            result['time'] = "解析时间出错"

        if art_content_div:
            result['content'] = art_content_div.get_text()
        else:
            result['content'] = "解析内容出错"

        return result

    except requests.RequestException as e:
        return {"error": f"发生错误：{e}"}

#函数get_sdxw_url使用示例
def ceshi1():
    # 使用示例
    keyword = "济南"
    page = 5
    entries = get_sdxw_url(keyword, page)
    for entry in entries:
        print(entry["Title"])
        print(entry["Publish Time"])
        print(entry['Thumbnail'])
#函数jx_sdxw使用示例
def ceshi2():
    y=jx_sdxw("https://sdxw.iqilu.com//w//article//YS0yMS0xNDk0NjEyMA.html")
    print(y)


def sdxw_engine(keyword, pages):
    data = []
    for i in range(pages):

        entries = get_sdxw_url(keyword, i)
        for entry in entries:
            link=(entry["URL"])
            title=(entry["Title"])

            time_content=jx_sdxw(link)
            time = time_content['time'].rstrip()
            timestamp=convert_to_timestamp(time)
            content = time_content['content']
            author = (entry["Copy From"])
            number="闪电新闻"+generate_random_md5()
            new_item = [title,time,timestamp,author,author,content,link,number]
            data.append(new_item)


    return data




