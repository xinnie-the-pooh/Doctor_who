import requests
import json
from bs4 import BeautifulSoup
from fake_useragent import UserAgent
import time

import hashlib
import random
import string


#随机生成编号
def generate_random_md5():
    # 生成随机字符串作为输入数据
    random_string = ''.join(random.choices(string.ascii_letters + string.digits, k=10))

    # 计算MD5哈希值
    md5_hash = hashlib.md5(random_string.encode()).hexdigest()

    return md5_hash


#时间戳转化
def convert_to_timestamp(time_string):
    format_string = "%Y-%m-%d %H:%M"  # 时间字符串的固定格式
    try:
        time_tuple = time.strptime(time_string, format_string)
        timestamp = int(time.mktime(time_tuple))
        return timestamp
    except ValueError:
        return None


#该函数用于获得海派新闻的新闻列表传入参数页码
def get_hpxw_url(pages):
    # 创建UserAgent对象并生成伪造的User-Agent
    ua = UserAgent()
    user_agent = ua.random

    url = "https://hb.dzwww.com/?act=getPCMoreNews&city=531&currPage={}".format(pages)
    headers = {
        "User-Agent": user_agent,
        "Accept": "application/json, text/javascript, */*; q=0.01",
        "Accept-Encoding": "gzip, deflate, br",
        "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8",
        "Referer": "https://hb.dzwww.com/",
        #"Cookie": "Hm_lvt_9ec9c2b973334b213091bc8e36f1a47d=1691577042; wdcid=763a8014b46dfb4c; wdses=15cb0bf1fb005fc5; PHPSESSID=3bq39ihp1h66ehagtcmd2pg3h2; has_sess=1; wdlast=1691577237; Hm_lpvt_9ec9c2b973334b213091bc8e36f1a47d=1691577237",
    }

    response = requests.get(url, headers=headers)

    parsed_data = json.loads(response.text)

    thumb_pics = parsed_data['news_list']

    results = []  # 存储所有条目的列表

    for pic in thumb_pics:
        result={
            "title": pic['title'],
            "thumb" : pic['thumb'],
            "url" : pic['real_url'],
            "ntime" : pic["ntime"]

        }
        results.append(result)
    return results


def jx_hpxw(url):
    try:
        # 发送GET请求获取网页内容
        response = requests.get(url)

        # 使用BeautifulSoup解析网页内容
        soup = BeautifulSoup(response.text, 'html.parser')

        time_label = soup.select_one('.news-head label:nth-of-type(2)').text
        source =soup.select_one('.news-head label:nth-of-type(1)').text
        author=soup.select_one('.news-head label:nth-of-type(3)').text


        # 找到具有art_content类的div元素
        art_content_div = soup.find('div', class_='news-body')

        result = {}

        if time_label:
            result['time'] = time_label
        else:
            result['time'] = "解析时间出错"

        if art_content_div:
            result['content'] = art_content_div.get_text()
        else:
            result['content'] = "解析内容出错"

        if source:
            result['source'] = source
        else:
            result['source'] = "解析来源出错"

        if author:
            result['author'] = author
        else:
            result['author'] = "解析作者出错"


        return result

    except requests.RequestException as e:
        return {"error": f"发生错误：{e}"}


#海报新闻引擎
def hpxw_engine(pages):
    data = []
    for i in range(pages):

        entries = get_hpxw_url(i)
        for entry in entries:
            link = (entry["url"])
            link ="https://"+link[2:]
            title = (entry["title"])
            time_content_author = jx_hpxw(link)
            time = time_content_author['time']

            content = time_content_author['content']
            source =time_content_author['source']
            author =time_content_author['author']
            number="海报新闻"+generate_random_md5()
            timestamp=convert_to_timestamp(time)
            new_item = [title, time, timestamp, source,author,content,link,number]
            data.append(new_item)

    return data

